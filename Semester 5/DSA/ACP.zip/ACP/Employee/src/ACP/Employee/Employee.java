package ACP.Employee;
import javax.swing.*;
import java.lang.*;
import java.io.Serializable;
import java.util.*;

public class Employee {
    String Emp_Name;
    String F_Name;
    String Job_Category;
    String Edu;
    String Nic;
    int E_Id;
    int P_Scale;
    String Dob;

    public Employee() {
        Emp_Name = null;
        F_Name = null;
        Job_Category = null;
        Edu = null;
        Nic = null;
        E_Id = 9000;
        P_Scale = 0;
        Dob = null;
    }

    void Set_Emp_Info(Employee emp) {
        int a=0,b=1,c=0;
        emp.Emp_Name = JOptionPane.showInputDialog(null, "Employee Name ", "Set Employee Information", JOptionPane.QUESTION_MESSAGE);
        emp.F_Name = JOptionPane.showInputDialog(null, "Father Name ", "Set Employee Information", JOptionPane.QUESTION_MESSAGE);
        emp.E_Id = ++E_Id;
        while (a<=0 || a>4) {
            a = Integer.parseInt(JOptionPane.showInputDialog(null, "Select Job Category 1 Teacher 2 Officer 3 Staff 4 Labour", "Set Employee Information", JOptionPane.QUESTION_MESSAGE));
            if (a == 1) {
                emp.Job_Category = "Teacher";
                while (c<17||c>22){
                    c = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter Your Pay Scale 18 - 22 ", "Set Employee Information ", JOptionPane.QUESTION_MESSAGE));
                }
                while (b < 0 || b > 2) {
                    b = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter Your Education \n 1. Phd \n 2. Ms ", "Set Employee Information ", JOptionPane.QUESTION_MESSAGE));
                }
            }
            else if (a == 2) {
                emp.Job_Category = "Officer";
                while (c<16||c>22){
                    c = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter Your Pay Scale 17 - 22 ", "Set Employee Information ", JOptionPane.QUESTION_MESSAGE));
                }
                while (b < 0 || b > 3) {
                    b = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter Your Education \n 1. Phd \n 2. Ms  \n 3. BS", "Set Employee Information ", JOptionPane.QUESTION_MESSAGE));
                }
            }
            else if (a == 3) {
                emp.Job_Category = "Staff";
                while (c<11||c>16){
                    c = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter Your Pay Scale 11 - 16 ", "Set Employee Information ", JOptionPane.QUESTION_MESSAGE));
                }
                while (b < 0 || b > 4) {
                    b = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter Your Education \n 1. Phd \n 2. Ms  \n 3. BS \n 4. Fsc", "Set Employee Information ", JOptionPane.QUESTION_MESSAGE));
                }
            }
            else if (a == 4) {
                emp.Job_Category = "Labour";
                while (c<1||c>10){
                    c = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter Your Pay Scale 1 - 10 ", "Set Employee Information ", JOptionPane.QUESTION_MESSAGE));
                }
                while (b <= 0 || b > 2) {
                    b = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter Your Education \n 1. Phd \n 2. Ms \n 3. BS \n 4. Fsc \n 5. Matric ", "Set Employee Information ", JOptionPane.QUESTION_MESSAGE));
                }
            }
            else {
                JOptionPane.showMessageDialog(null, "Invalid Entry", "Error Message", JOptionPane.ERROR_MESSAGE);
            }
        }
        emp.P_Scale=c;
        if (b==1)
        {
            emp.Edu="Phd";
        }
        else if (b==2) {
            emp.Edu="Ms";
        } else if (b==3) {
            emp.Edu="Bs";
        }
        else if (b==4){
            emp.Edu="Fsc";
        }
        else {
            emp.Edu="Matric";
        }
        emp.Dob=JOptionPane.showInputDialog(null,"Enter Your Date of Birth","1-1-1970");
        emp.Nic=JOptionPane.showInputDialog(null,"Enter Your CNIC","11111-1111111-1");

    }

    void Search$View_Employee(){

    }
    public static void main(String[] args){
        Employee emp1 = new Employee();
        emp1.Set_Emp_Info(emp1);
        JOptionPane.showMessageDialog(null,emp1.E_Id + emp1.Edu + emp1.Job_Category + emp1.P_Scale + emp1.Dob);
        Employee emp2 = new Employee();
        emp1.Set_Emp_Info(emp2);
        Employee emp3 = new Employee();
        emp1.Set_Emp_Info(emp3);
        Employee emp4 = new Employee();
        emp1.Set_Emp_Info(emp4);
    }
}
