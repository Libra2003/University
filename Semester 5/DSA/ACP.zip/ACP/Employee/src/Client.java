import ACP.Employee.Employee;
import javax.swing.*;
import java.util.*;
public class Client extends Employee {
    static int j = 0;
    static Employee[] emp = new Employee[50];

    public static void main(String args[]) {
        for (int i = 0; i < 50; i++) {
            emp[i] = new Employee();
        }
        emp[j].



    }
}
