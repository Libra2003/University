<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$data = json_decode(file_get_contents("php://input"));

$UserName = $data->UserName;
$reg_email = $data->reg_email;
$reg_password = $data->reg_password;
$phone_Number = $data->phone_Number;
$plans = $data->plans;

$con = mysqli_connect("localhost:3306", "root", "rootpassword");
mysqli_select_db($con, "user_info");

// Check if the username already exists
$usernameQuery = "SELECT * FROM user_info WHERE UserName = '$UserName'";
$usernameResult = mysqli_query($con, $usernameQuery);


if (mysqli_num_rows($usernameResult) > 0) {
    // Username already exists, send an error response to React
    $response['data'] = array(
        'status' => 'invalid',
        'message' => 'Username already exists'
    );
    echo json_encode($response);
    exit();
}

// Check if the email already exists
$emailQuery = "SELECT * FROM user_info WHERE reg_email = '$reg_email'";
$emailResult = mysqli_query($con, $emailQuery);

if (mysqli_num_rows($emailResult) > 0) {
    // Email already exists, send an error response to React
    $response['data'] = array(
        'status' => 'invalid',
        'message' => 'Email already exists'
    );
    echo json_encode($response);
    exit();
}

if ($UserName && $reg_email && $phone_Number) {
    $sql = "INSERT INTO user_info (UserName, reg_email, reg_password, phone_Number, Plan) VALUES (
        '$UserName',
        '$reg_email',
        '$reg_password',
        '$phone_Number',
        '$plans'
    )";

    $result = mysqli_query($con, $sql);

    if ($result) {
        $response['data'] = array(
            'status' => 'valid'
        );
        echo json_encode($response);

    } else {
        $response['data'] = array(
            'status' => 'invalid',
            'message' => 'Error occurred while registering'
        );
        echo json_encode($response);
    }

}

mysqli_close($con);
?>
