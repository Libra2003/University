<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['email']) && isset($_POST['password'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];
        
        $con = mysqli_connect("localhost", "root", "rootpassword", "user_info");
        if ($con->connect_error) {
            die("Failed to connect: " . $con->connect_error);
        } else {
            $stmt = $con->prepare("SELECT * FROM user_info WHERE reg_email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt_result = $stmt->get_result();
            
            $isValidLogin = false;
            
            while ($data = $stmt_result->fetch_assoc()) {
                if ($data['reg_email'] === $email && $data['reg_password'] === $password) {
                    $isValidLogin = true;
                    break;
                }
            }
            
            if ($isValidLogin) {
                // Redirect to another page on successful login
                header("Location: http://localhost:3000/lifeInvader?isValidLogin=true");
                exit(); // Make sure to exit after the redirect
            } else {
                header("Location: http://localhost:3000/Login?isValidLogin=false");
            }
        }
    }
}
?>
